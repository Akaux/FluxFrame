#!/usr/bin/env bash
# Instala o Framegen + painel no CachyOS/Arch (KDE Plasma). Sem root, exceto para os pacotes do pacman.
#   bash install.sh            instala
#   bash install.sh --remove   desinstala tudo
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/framegen"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
ICONS="$HOME/.local/share/icons/hicolor/scalable/apps"

if [[ "${1:-}" == "--remove" ]]; then
  rm -rf "$DEST" "$BIN/framegen-gui" "$APPS/framegen.desktop" "$ICONS/framegen.svg" \
         "$HOME/.cache/framegen-gui" "$HOME/.config/framegen"
  update-desktop-database "$APPS" 2>/dev/null || true
  echo "Framegen removido."; exit 0
fi

[[ -f "$SRC/live.py" && -f "$SRC/framegen_gui.py" ]] || { echo "Rode na pasta que tem live.py e framegen_gui.py"; exit 1; }

echo "==> Pacotes do sistema (captura Wayland, portal, atalhos globais)"
sudo pacman -S --needed --noconfirm python python-gobject python-evdev \
  gst-plugin-pipewire gst-plugins-base gst-plugins-good xdg-desktop-portal-kde

echo "==> Copiando arquivos para $DEST"
mkdir -p "$DEST" "$BIN" "$APPS" "$ICONS"
cp "$SRC"/{live,overlay,framegen,capture_wayland,bench,hotkeys,framegen_gui}.py "$DEST/"
cp "$SRC/framegen.svg" "$DEST/" && cp "$SRC/framegen.svg" "$ICONS/framegen.svg"

echo "==> Ambiente Python (enxerga o gi/evdev do sistema)"
[[ -x "$DEST/.venv/bin/python" ]] || python -m venv --system-site-packages "$DEST/.venv"
if ! "$DEST/.venv/bin/pip" install --upgrade numpy opencv-python PySide6-Essentials PyOpenGL; then
  echo "pip falhou; usando os pacotes do pacman (maiores)."
  sudo pacman -S --needed --noconfirm pyside6 python-numpy python-opencv python-pyopengl
fi

cat > "$BIN/framegen-gui" <<LAUNCH
#!/usr/bin/env bash
exec "$DEST/.venv/bin/python" "$DEST/framegen_gui.py" "\$@"
LAUNCH
chmod +x "$BIN/framegen-gui"
cp "$SRC/framegen.desktop" "$APPS/framegen.desktop"
update-desktop-database "$APPS" 2>/dev/null || true
command -v kbuildsycoca6 >/dev/null && kbuildsycoca6 >/dev/null 2>&1 || true

echo
echo "Pronto. Abra \"Framegen\" no menu do KDE ou rode: framegen-gui"
if ! id -nG | grep -qw input; then
  echo
  echo "Atalhos globais (Ctrl+Alt+F/H/N) precisam do grupo 'input':"
  echo "  sudo usermod -aG input \$USER   (depois saia e entre na sessão)"
fi
[[ ":$PATH:" == *":$BIN:"* ]] || echo "Obs.: adicione $BIN ao PATH (fish: fish_add_path ~/.local/bin)."
